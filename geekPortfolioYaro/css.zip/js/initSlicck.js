 $('.slide').slick ({
  
  
    prevArrow: "<img src='js/back.svg' class='prev' alt='1'>",
    nextArrow: "<img src='js/next.svg' class='next' alt='2'>",
    });
